class Welcome:
    """ this is from welcome class docstring"""
print(Welcome.__doc__)
help(Welcome)