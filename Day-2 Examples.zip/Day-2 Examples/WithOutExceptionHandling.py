try:
    result = 12 / "sandeep" #PVM
    print("Result is", result)#error code/risky code 
except ZeroDivisionError as obj:
    print("denominator cannot be zero")
except  Exception as obj:
    print("some other exception",obj.__class__) 
print("Remaining lines of code")
#system defined error messages
#abnormal termination


#normal ternimation
#user friendly error message 












