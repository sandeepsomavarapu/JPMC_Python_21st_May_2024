class Student:
    '''developed by rps for python'''
    def __init__(self,id,name,marks):
        print("param constructor")
        self.id=id
        self.name=name
        self.marks=marks
    def printStudent(self):
        print("student id :",self.id)
        print("student name :",self.name)
        print("student marks :",self.marks)
student=Student(222,'mahesh',345)#object creation
student1=Student(333,'suresh',545)#object creation
student.printStudent()
student1.printStudent()