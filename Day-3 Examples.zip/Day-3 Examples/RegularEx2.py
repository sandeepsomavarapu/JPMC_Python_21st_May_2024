import re
count=0
matcher=re.finditer("ab","abaababa")
print(matcher)
for match in matcher:
    print(match.start(),"...",match.end(),"..",match.group())
    count+=1
print("Count of ab's ",count)