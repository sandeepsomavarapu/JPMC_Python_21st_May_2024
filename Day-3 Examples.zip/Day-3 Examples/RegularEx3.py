import re

matcher=re.finditer("\\D","a7b@k9Z") #[abc]
for match in matcher:
    print(match.start(),"...",match.group())