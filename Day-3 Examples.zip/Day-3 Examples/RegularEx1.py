import re
count=0
pattern=re.compile("ab")
matcher=pattern.finditer("abaababa")
print(matcher)
for match in matcher:
    print(match.start(),"...",match.end(),"..",match.group())
    count+=1
print("Count of ab's ",count)