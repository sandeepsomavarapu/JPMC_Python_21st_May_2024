number=int(input('Please enter any integer value'))  # "123"
if number>=1:
	print('You Have Entered Positive Integer')	
print('This message is not coming from python if statement')

